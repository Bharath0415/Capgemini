package Assignment3;

public class Assignment3Q7 {
	public static void main(String[] args) {
		StringBuilder str = new StringBuilder("");
		str.append("StringBuilder");
		str.append(" is a peer class of String");
		str.append(" that provides much of");
		str.append(" the functionality of strings");
		System.out.println(str);
	}
}
