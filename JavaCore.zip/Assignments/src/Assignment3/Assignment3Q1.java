package Assignment3;

public class Assignment3Q1 {
	public static void main(String[] args) {
		String str="Hello World";
		int length=str.length();
		System.out.println(length);
		
	}

}
