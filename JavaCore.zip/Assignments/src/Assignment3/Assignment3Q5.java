package Assignment3;

public class Assignment3Q5 {

	public static void main(String[] args) {
		StringBuffer str=new StringBuffer("It is used to  at the specified index position");
		str.insert(14, "insert text");
		System.out.println(str);
	}

}
