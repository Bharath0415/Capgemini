package Assignment3;

public class Assignment3Q6 {
	public static void main(String[] args) {
		StringBuffer str = new StringBuffer("This method returns the reversed object on which it was called");
		System.out.println(str.reverse());
		
	}
}
