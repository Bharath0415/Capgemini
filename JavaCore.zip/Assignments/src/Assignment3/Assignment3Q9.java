package Assignment3;

public class Assignment3Q9 {
	public static void main(String[] args) {
		StringBuilder str = new StringBuilder("This method returns the reversed object on which it was called");
		System.out.println(str.reverse());
		
	}
}
