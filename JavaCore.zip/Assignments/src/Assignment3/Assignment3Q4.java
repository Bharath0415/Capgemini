package Assignment3;

public class Assignment3Q4 {
	public static void main(String[] args) {
		StringBuffer str = new StringBuffer("");
		str.append("StringBuffer");
		str.append(" is a peer class of String");
		str.append(" that provides much of");
		str.append(" the functionality of strings");
		System.out.println(str);
	}
}
