package Assignment3;

public class Assignment3Q2 {
	public static void main(String[] args) {
		String str1="Hello";
		String str2=" World";
		String str3=str1.concat(str2);
		System.out.println(str3);
	}
}
