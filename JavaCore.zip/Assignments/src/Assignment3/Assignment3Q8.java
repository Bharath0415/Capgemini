package Assignment3;

public class Assignment3Q8 {

	public static void main(String[] args) {
		StringBuilder str=new StringBuilder("It is used to  at the specified index position");
		str.insert(14, "insert text");
		System.out.println(str);
	}

}