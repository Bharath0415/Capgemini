package assignment10;

public class Assignment10Q2 {
	
	//public static operation(var a,var b) {} ----> var can not be used to declare variables as parameters in method
	
/*public double operate() {
		var a;}// ----> can not use var without initializer*/
	
	public static void main(String[] args) {
	
	}
	
	

}
//class var{} ----> var can not be used as class name.