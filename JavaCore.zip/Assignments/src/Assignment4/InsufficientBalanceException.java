package Assignment4;

public class InsufficientBalanceException extends Exception {
	
}
