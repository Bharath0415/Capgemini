package Assignment4;

public class IllegalBankTransactionException extends Exception {

}
